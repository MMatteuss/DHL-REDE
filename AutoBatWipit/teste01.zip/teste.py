import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException

# ================= CONFIGURAÇÕES =================
EXCEL_PATH = r"C:\Users\jocza1\OneDrive - DPDHL\Documents\usuarios\T3\teste\BateriaTeste.xlsx"
BASE_URL = "https://dhl-rede.triage-wipit.com/dhlrede/processing/orders/TriageOrder"
SUCCESS_MESSAGE_PARAM = "Processo%20executado%20com%20sucesso"

# Inicializa o driver (assumindo ChromeDriver no PATH)
driver = webdriver.Chrome()
wait = WebDriverWait(driver, 10)

def select_triage_battery():
    """Seleciona a opção 'Triage-Battery' no dropdown inicial."""
    dropdown = Select(wait.until(EC.presence_of_element_located((By.ID, "identifierDropdown"))))
    dropdown.select_by_value("Triage-Battery")
    time.sleep(0.5)

def fill_sereal(sereal):
    """Preenche o campo 'InputOne' com o sereal da bateria."""
    input_one = wait.until(EC.presence_of_element_located((By.ID, "InputOne")))
    input_one.clear()
    input_one.send_keys(sereal)

def fill_sku(sku):
    """Preenche o campo 'Inserir SKU'."""
    sku_input = wait.until(EC.presence_of_element_located(
        (By.XPATH, "//div[contains(@class,'textbox-wc')][.//label[text()='Inserir SKU']]//input")
    ))
    sku_input.clear()
    sku_input.send_keys(sku)

def fill_defect(has_defect):
    """Preenche o campo 'Apresenta defeito' com 'Yes' ou 'No'."""
    defect_input = wait.until(EC.presence_of_element_located((By.ID, "wc-9985-input")))
    defect_input.clear()
    defect_input.send_keys("Yes" if has_defect else "No")
    time.sleep(0.3)
    defect_input.send_keys(Keys.TAB)  # confirma a opção

def fill_tipo(tipo):
    """Seleciona o tipo de problema no dropdown com checkboxes."""
    header = wait.until(EC.element_to_be_clickable((By.ID, "wc-9988-header")))
    header.click()
    time.sleep(0.3)
    option_xpath = f"//div[@id='wc-9988-list']//label[@data-value='{tipo}']"
    try:
        option_label = wait.until(EC.element_to_be_clickable((By.XPATH, option_xpath)))
        checkbox = option_label.find_element(By.CSS_SELECTOR, "input[type='checkbox']")
        if not checkbox.is_selected():
            checkbox.click()
        # Fecha o dropdown clicando fora
        driver.find_element(By.TAG_NAME, "body").click()
    except TimeoutException:
        print(f"Tipo de problema '{tipo}' não encontrado no dropdown.")

def fill_bin(bin_value):
    """Preenche o campo 'Insira o BIN destino'."""
    bin_input = wait.until(EC.presence_of_element_located(
        (By.XPATH, "//div[contains(@class,'textbox-wc')][.//label[text()='Insira o BIN destino']]//input")
    ))
    bin_input.clear()
    bin_input.send_keys(bin_value)

def click_next():
    """Clica no botão Next e aguarda a mensagem de sucesso na URL."""
    next_btn = wait.until(EC.element_to_be_clickable((By.ID, "nextBtn")))
    next_btn.click()
    try:
        wait.until(lambda d: SUCCESS_MESSAGE_PARAM in d.current_url)
        return True
    except TimeoutException:
        print("Timeout: A mensagem de sucesso não apareceu na URL.")
        return False

def process_row(row):
    """Executa o fluxo completo para uma linha da planilha."""
    sereal = row['sereal']
    sku = row['sku']
    problema = str(row['problema']).strip().lower()
    tipo = row['tipo'] if pd.notna(row['tipo']) else ""
    bin_value = row['bin'] if pd.notna(row['bin']) else ""

    print(f"\nProcessando sereal: {sereal} | SKU: {sku} | Problema: {problema}")

    # Navega para a página inicial (garante estado limpo)
    driver.get(BASE_URL)

    # 1. Seleciona Triage-Battery
    select_triage_battery()

    # 2. Preenche o sereal
    fill_sereal(sereal)

    # 3. Preenche SKU
    fill_sku(sku)

    # 4. Preenche defeito
    has_defect = (problema == "yes")
    fill_defect(has_defect)

    # 5. Se tiver defeito, preenche o tipo
    if has_defect and tipo:
        fill_tipo(tipo)
    elif has_defect and not tipo:
        print("Aviso: Problema = Yes mas nenhum tipo informado. Pulando seleção de tipo.")

    # 6. Preenche BIN
    fill_bin(bin_value)

    # 7. Clica em Next e verifica sucesso
    success = click_next()
    if success:
        print(f"✅ Sereal {sereal} processado com sucesso.")
    else:
        print(f"❌ Falha ao processar sereal {sereal}. URL atual: {driver.current_url}")

def main():
    try:
        # Lê a planilha
        df = pd.read_excel(EXCEL_PATH)
        required_cols = ['sereal', 'sku', 'problema', 'tipo', 'bin']
        for col in required_cols:
            if col not in df.columns:
                raise ValueError(f"Planilha não contém a coluna obrigatória: {col}")

        # Itera sobre as linhas
        for index, row in df.iterrows():
            process_row(row)

        print("\n✅ Processamento concluído para todas as linhas.")
    except Exception as e:
        print(f"❌ Erro geral: {e}")
    finally:
        driver.quit()

if __name__ == "__main__":
    main()