import pyautogui
import time
import keyboard
import pyperclip

print("Script: primeiro clique (após 3s), pressione ENTER para começar a verificação.")
print("Loop infinito. Ctrl+C para parar.\n")

sku="COM20250006"
subLpn='LPNR059835'

def verificar_texto():
    pyautogui.hotkey('ctrl', 'a')
    time.sleep(0.2)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(0.2)
    texto = pyperclip.paste()
    if "Inserir SKU" in texto:
        return "sku"
    elif "Triage Order Initiation" in texto:
        return "triage"
    else:
        return None

try:
    while True:
        # --- Primeira parte: clicar e aguardar Enter ---
        time.sleep(2)
        pyautogui.press('down')
        time.sleep(0.1)
        pyautogui.click(383, 552)
        
        keyboard.wait('enter')   # aguarda Enter global
        
        # --- Verificação contínua até achar um dos textos ---
        while True:
            estado = verificar_texto()
            if estado == "sku":
                print("'Inserir SKU' encontrado! Vou preencher os dados.")
                break  # sai do loop de verificação e vai para o preenchimento
            elif estado == "triage":
                print("'Triage Order Initiation' encontrado! Vou voltar a esperar Enter.")
                break  # sai do loop de verificação mas sem preencher (vai recomeçar)
            else:
                print("Texto não identificado. Tentando novamente em 0.5s...")
                time.sleep(0.5)
        
        # --- Decisão após a verificação ---
        if estado == "triage":
            # Volta ao início do loop principal (aguarda Enter novamente)
            continue
        
        # Se chegou aqui, é porque estado == "sku" -> executa o preenchimento
        pyautogui.click(383, 552)
        pyautogui.write(sku)
        pyautogui.hotkey('tab')
        pyautogui.write("no")
        pyautogui.hotkey('tab')
        pyautogui.write(subLpn)
        pyautogui.hotkey('enter')
        
        print("Ciclo concluído. Reiniciando...\n")
        time.sleep(1)

except KeyboardInterrupt:
    print("\nPrograma finalizado.")